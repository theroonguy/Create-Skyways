#version 120
#define DIMENSION_OVERWORLD

#include "/program/gbuffers_entities.fsh"
