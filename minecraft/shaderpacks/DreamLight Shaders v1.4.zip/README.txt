DreamLight Shaders v1.4

A warm, dreamy visual experience for Minecraft.

DreamLight Shaders focuses on soft tones, balanced lighting, and smooth performance — perfect for cozy, atmospheric worlds.
It enhances sunlight, skies, and reflections while keeping the look natural and soothing.

v1.4 Changes:
- Improved water rendering with better dual-layer normals and foam edge
- Enhanced bloom with luminance-aware mixing and better curve
- Better atmospheric fog with improved height falloff
- Improved cloud lighting with silver lining effect
- Better night sky with enhanced star rendering
- Improved SSAO with depth-aware falloff
- Enhanced god rays with smoother falloff
- New "Ethereal" color scheme (scheme 4)
- Optional Depth of Field effect
- Various performance optimizations and bug fixes

Credits

This shader is a remake of Mellow Shader by TheCMK.
Original Mellow Shader: https://www.curseforge.com/minecraft/shaders/mellow

Special thanks to TheCMK for the original creative base and inspiration.